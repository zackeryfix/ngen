#include "Ngen.hpp"

using namespace Ngen;

int main() {
    Console::WriteLine(const_text("Hello World! ~ From the Ngen Framework - v0.1"));
    return 0;
}